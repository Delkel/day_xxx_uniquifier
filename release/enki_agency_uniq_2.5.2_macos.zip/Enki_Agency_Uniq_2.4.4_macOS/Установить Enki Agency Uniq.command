#!/bin/bash
set -Eeuo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
APP_SRC="$DIR/Enki Agency Uniq.app"
APP_DST="$HOME/Applications/Enki Agency Uniq.app"
LOG_DIR="$HOME/Library/Logs/Enki Agency Uniq"
mkdir -p "$LOG_DIR"

fail() {
  echo
  echo "Установка не завершена. Журнал: $LOG_DIR/install.log"
  osascript -e 'display dialog "Установка не завершена. Откройте журнал установки в папке Library/Logs/Enki Agency Uniq." buttons {"OK"} default button "OK" with icon stop' >/dev/null 2>&1 || true
  read -r -p "Нажмите Enter, чтобы закрыть окно..." _ || true
}
trap fail ERR

clear
printf '%s\n' "== Enki Agency Uniq 2.4.4 =="
[ -d "$APP_SRC" ] || { echo "Не найдено приложение рядом с установщиком."; exit 1; }

# Stop only this application; never opens the installer recursively.
pkill -f '/Enki Agency Uniq.app/Contents/MacOS/enki_agency_uniq' 2>/dev/null || true

# Remove only obsolete app copies and the broken dependency environment.
rm -rf "$HOME/Applications/DuckyBruto Uniq.app" \
       "$HOME/Applications/@day_xxx Uniquifier.app" \
       "$APP_DST" \
       "$HOME/Library/Application Support/Enki Agency Uniq/venv"

mkdir -p "$HOME/Applications"
ditto "$APP_SRC" "$APP_DST"
chmod +x "$APP_DST/Contents/MacOS/enki_agency_uniq" \
         /bin/bash "$APP_DST/Contents/Resources/bootstrap.sh"
xattr -dr com.apple.quarantine "$APP_DST" 2>/dev/null || true

/bin/bash "$APP_DST/Contents/Resources/bootstrap.sh"

echo "Запускаю приложение..."
open "$APP_DST"
osascript -e 'display notification "Установлено и запущено" with title "Enki Agency Uniq"' >/dev/null 2>&1 || true
sleep 2
exit 0

ENKI AGENCY UNIQ 2.4.1

1. Распакуйте архив.
2. Нажмите правой кнопкой на «Установить Enki Agency Uniq.command» → «Открыть».
3. Дождитесь запуска приложения.

Установщик использует uv с отдельным Python 3.12, поэтому не зависит от старых Python-окружений и ensurepip.
Рабочие файлы: ~/Movies/Enki Agency Uniq
Журналы: ~/Library/Logs/Enki Agency Uniq
Обновления: кнопка внутри приложения читает GitHub update-manifest.json.

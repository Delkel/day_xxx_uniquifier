#!/bin/bash
set -Eeuo pipefail

APP_NAME="Enki Agency Uniq"
SUPPORT_DIR="$HOME/Library/Application Support/$APP_NAME"
VENV_DIR="$SUPPORT_DIR/venv"
LOG_DIR="$HOME/Library/Logs/$APP_NAME"
LOG_FILE="$LOG_DIR/install.log"
LOCK_DIR="/tmp/enki_agency_uniq_install_${UID}.lock"

export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
mkdir -p "$SUPPORT_DIR" "$LOG_DIR"
exec > >(tee "$LOG_FILE") 2>&1

cleanup() { rm -rf "$LOCK_DIR"; }
trap cleanup EXIT

if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  echo "Установка уже запущена. Дождитесь завершения открытого окна."
  exit 2
fi

echo "== Enki Agency Uniq: установка =="

auto_brew_shellenv() {
  if [ -x /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [ -x /usr/local/bin/brew ]; then
    eval "$(/usr/local/bin/brew shellenv)"
  fi
}

if ! command -v brew >/dev/null 2>&1; then
  echo "Устанавливаю Homebrew..."
  NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  auto_brew_shellenv
fi

auto_brew_shellenv

echo "Проверяю FFmpeg и установщик Python..."
brew install uv ffmpeg

UV_BIN="$(command -v uv)"
[ -x "$UV_BIN" ] || { echo "Ошибка: uv не найден после установки."; exit 10; }

# uv manages its own Python and does not depend on ensurepip from Homebrew Python.
echo "Подготавливаю Python 3.12..."
"$UV_BIN" python install 3.12

echo "Создаю чистое окружение..."
rm -rf "$VENV_DIR"
"$UV_BIN" venv --python 3.12 "$VENV_DIR"

echo "Устанавливаю интерфейс..."
"$UV_BIN" pip install --python "$VENV_DIR/bin/python" "PySide6>=6.7,<7"

"$VENV_DIR/bin/python" - <<'PY'
import PySide6
print("PySide6 готов:", PySide6.__version__)
PY

command -v ffmpeg >/dev/null
command -v ffprobe >/dev/null

echo "Установка завершена."
